#!/bin/bash
helm install --tls rds-mysql-operator --name=mysql-operator --namespace=rds
