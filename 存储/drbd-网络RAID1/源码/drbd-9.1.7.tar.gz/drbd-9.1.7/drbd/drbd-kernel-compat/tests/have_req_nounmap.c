/* { "version": "v4.11-rc5", "commit": "d928be9f853b9755692d7e9aed402c1809a88e56", "author": "Christoph Hellwig <hch@lst.de>", "date": "Wed Apr 5 19:21:09 2017 +0200" } */
#include <linux/blk_types.h>

int dummy = REQ_NOUNMAP;
