/* { "version": "v5.6-rc6", "commit": "c6a564ffadc9105880329710164ee493f0de103c", "comment": "The part_stat* helpers were moved to a new header", "author": "Christoph Hellwig <hch@lst.de>", "date": "Wed Mar 25 16:48:42 2020 +0100" } */

#include <linux/part_stat.h>
