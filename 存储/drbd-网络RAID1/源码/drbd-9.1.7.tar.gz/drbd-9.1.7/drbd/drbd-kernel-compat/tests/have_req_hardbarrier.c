#include <linux/bio.h>

int dummy = REQ_HARDBARRIER;
