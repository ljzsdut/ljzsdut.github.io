#include <net/genetlink.h>

struct genl_ops ops = { .policy = NULL, };
