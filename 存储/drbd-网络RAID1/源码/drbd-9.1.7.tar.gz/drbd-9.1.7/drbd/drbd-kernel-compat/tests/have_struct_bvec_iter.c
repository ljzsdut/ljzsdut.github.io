#include <linux/blk_types.h>

int main(void)
{
	struct bvec_iter iter = {};

	return 0;
}
