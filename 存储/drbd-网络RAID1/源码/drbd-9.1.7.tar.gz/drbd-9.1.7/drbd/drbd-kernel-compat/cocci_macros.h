#define __must_hold(x)
#define __printf(x, y)
